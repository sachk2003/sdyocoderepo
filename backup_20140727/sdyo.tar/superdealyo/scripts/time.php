<?php
$timestamp = time();
echo $timestamp;:wq
?>
